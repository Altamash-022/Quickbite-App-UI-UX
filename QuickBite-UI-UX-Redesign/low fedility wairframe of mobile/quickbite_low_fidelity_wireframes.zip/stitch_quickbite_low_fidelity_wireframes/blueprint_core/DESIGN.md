---
name: Blueprint Core
colors:
  surface: '#f9f9f9'
  surface-dim: '#dadada'
  surface-bright: '#f9f9f9'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3f4'
  surface-container: '#eeeeee'
  surface-container-high: '#e8e8e8'
  surface-container-highest: '#e2e2e2'
  on-surface: '#1a1c1c'
  on-surface-variant: '#45464c'
  inverse-surface: '#2f3131'
  inverse-on-surface: '#f0f1f1'
  outline: '#76777d'
  outline-variant: '#c6c6cd'
  surface-tint: '#575e70'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#141b2b'
  on-primary-container: '#7d8497'
  inverse-primary: '#c0c6db'
  secondary: '#5c5f60'
  on-secondary: '#ffffff'
  secondary-container: '#dee0e2'
  on-secondary-container: '#606365'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#151c25'
  on-tertiary-container: '#7d8490'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dce2f7'
  primary-fixed-dim: '#c0c6db'
  on-primary-fixed: '#141b2b'
  on-primary-fixed-variant: '#404758'
  secondary-fixed: '#e1e2e4'
  secondary-fixed-dim: '#c5c6c8'
  on-secondary-fixed: '#191c1e'
  on-secondary-fixed-variant: '#444749'
  tertiary-fixed: '#dce3f0'
  tertiary-fixed-dim: '#c0c7d3'
  on-tertiary-fixed: '#151c25'
  on-tertiary-fixed-variant: '#404752'
  background: '#f9f9f9'
  on-background: '#1a1c1c'
  surface-variant: '#e2e2e2'
typography:
  headline-lg:
    fontFamily: Inter
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-caps:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  container-margin: 1rem
  stack-gap: 1rem
  inline-gap: 0.75rem
  section-padding: 1.5rem
---

## Brand & Style

The design system is a utility-first framework focused on structural clarity and functional hierarchy. It adopts a **Minimalist / Wireframe** aesthetic to strip away visual distractions, allowing stakeholders to focus entirely on information architecture, user flow, and content density. 

The system utilizes a high-contrast grayscale palette to establish a clear "Action vs. Information" relationship. By removing color, the interface relies on scale, weight, and spacing to communicate importance. The emotional response is one of clinical precision, efficiency, and neutrality.

## Colors

This design system uses a strict monochromatic palette to define depth and interaction states:

- **Primary (#111827):** Reserved for high-priority text, primary buttons, and active states.
- **Secondary (#F3F4F6):** Used for background fills, input fields, and differentiating surface areas from the main canvas.
- **Tertiary (#9CA3AF):** Applied to placeholder content, icons of secondary importance, and disabled states.
- **Base (#FFFFFF):** The standard background for the app canvas and elevated cards.
- **Border (#D1D5DB):** A structural gray used for hair-line strokes to define boundaries without adding visual weight.

## Typography

The system uses **Inter** for its neutral, highly legible characteristics. Typographic hierarchy is achieved through significant weight shifts (Bold vs. Regular) rather than color shifts. 

- **Headlines:** Use Bold weights to anchor the page. Use `headline-lg-mobile` for top-level screen titles.
- **Body Text:** Standardized at 16px for readability. Use `body-sm` for secondary metadata.
- **Labels:** Use `label-caps` for small headers (like section titles in a list) to provide structure without using large font sizes.

## Layout & Spacing

This design system follows a **fluid grid** model optimized for mobile constraints. 

- **Margins:** A consistent 16px (1rem) safe area is maintained on the left and right edges of all screens.
- **Rhythm:** An 8px base unit drives all spacing. Elements are stacked using 16px gaps for related items and 24px-32px gaps for distinct sections.
- **Verticality:** Content should be grouped in vertical stacks. Lists and cards should span the full width of the container margin.

## Elevation & Depth

To maintain a low-fidelity feel, the design system avoids shadows. Depth is communicated through **Tonal Layers** and **Borders**:

- **Level 0 (Canvas):** Pure White (#FFFFFF).
- **Level 1 (Sections/Inputs):** Light Gray (#F3F4F6) background fills or 1px strokes (#D1D5DB).
- **Level 2 (Modals/Overlays):** White surfaces with a heavy 2px Black (#111827) border to simulate physical "stacking" without using blurs or glows.

## Shapes

The design system uses a **Soft (0.25rem)** rounding strategy. This maintains a professional, modern look while ensuring the wireframe doesn't feel overly harsh or "brutalist." 

- **Small Components:** 4px radius (Buttons, Input Fields, Chips).
- **Large Components:** 8px radius (Cards, Image Placeholders).
- **Interactive Triggers:** Secondary buttons and icons maintain the same 4px radius for consistency.

## Components

- **Buttons:** 
  - *Primary:* Solid Black (#111827) fill with White text.
  - *Secondary:* White background with a 1px Black border.
- **Image Placeholders:** Medium Gray (#9CA3AF) rectangles with a centered "X" stroke or a simple image icon in the center.
- **Inputs:** Light Gray (#F3F4F6) fill with a bottom-only border or a full 1px border. Placeholders use Medium Gray (#9CA3AF).
- **Cards:** Simple White containers with a 1px #D1D5DB border. No shadows.
- **Chips:** Small, rounded containers with a #F3F4F6 fill for categories or filters.
- **Lists:** Separated by 1px horizontal dividers (#F3F4F6). Icons in lists should be simple line-art or 24x24px gray boxes.
- **Checkboxes/Radios:** High-contrast Black and White. Checked states are solid Black.